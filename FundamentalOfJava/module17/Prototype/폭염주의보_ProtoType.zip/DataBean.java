public interface DataBean extends Cloneable{
    public DataBean clone();
}
