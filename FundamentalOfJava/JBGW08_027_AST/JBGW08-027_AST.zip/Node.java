public interface Node {
    int evaluation();
}